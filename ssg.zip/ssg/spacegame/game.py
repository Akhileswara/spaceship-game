from re import X
import pygame
import random
from models import Asteroid,Spaceship

from utils import get_random_position, load_sprite, print_text,load_sound
class Spacegame:
    
    MIN_ASTEROID_DISTANCE = 250
    def __init__(self):
        self._init_pygame()
        WIDTH,HEIGHT=800,500
        self.screen = pygame.display.set_mode((WIDTH,HEIGHT))
        self.background = load_sprite("spacex", False)
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 32)
        self.message = ''' '''
        self.asteroids = []
        self.bullets = []
        self.x=random.randint(6,10)
        self.spaceshipx = Spaceship((400, 300), self.bullets.append)
        self.space_sound = load_sound("space")
        self.space_sound.play()
        for _ in range(self.x):
            while True:
                position = get_random_position(self.screen)
                if (
                    position.distance_to(self.spaceshipx.position)
                    > self.MIN_ASTEROID_DISTANCE
                ):
                    break
            self.asteroids.append(Asteroid(position, self.asteroids.append))
    def main_loop(self):
        while True:
            self._handle_input()
            self._process_game_logic()
            self._draw()
    def _init_pygame(self):
        pygame.init()
        pygame.display.set_caption("Astroide game")
    def _handle_input(self):
        is_key_pressed = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
                quit()
            else:
                if is_key_pressed[pygame.K_TAB]:
                    Spacegame.__init__(self)
            if (self.spaceshipx and event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE):
                self.spaceshipx.shoot()
        is_key_pressed = pygame.key.get_pressed()
        if self.spaceshipx:
            if is_key_pressed[pygame.K_RIGHT]:
                self.spaceshipx.rotate(clockwise=True)
                self.spaceshipx.accelerate()
            elif is_key_pressed[pygame.K_LEFT]:
                self.spaceshipx.rotate(clockwise=False)
                self.spaceshipx.accelerate()
            if is_key_pressed[pygame.K_UP]:
                self.spaceshipx.accelerate()
            if is_key_pressed[pygame.K_DOWN]:
                self.spaceshipx.accelerate1()
                
    def _process_game_logic(self):
        
        self.lost_sound = load_sound("lost")
        self.won_sound = load_sound("won")
        
        for game_object in self._get_game_objects():
            game_object.move(self.screen)
        for bullet in self.bullets[:]:
            for asteroid in self.asteroids[:]:
    
                if asteroid.collides_with(bullet):
                    
                    self.asteroids.remove(asteroid)
                    self.bullets.remove(bullet)
                    asteroid.split()

                    break
        if self.spaceshipx:
            is_key_pressed = pygame.key.get_pressed()
            for asteroid in self.asteroids:
                if asteroid.collides_with(self.spaceshipx):
                    self.spaceshipx = None
                    self.message = '''You lost! score is '''+str(self.x-self.n)+''' press tab to restart'''
                    self.lost_sound.play()
                    break
        
        for bullet in self.bullets[:]:
            
            if not self.screen.get_rect().collidepoint(bullet.position):
                self.bullets.remove(bullet)

        if not self.asteroids and self.spaceshipx:
            
            self.message = '''You won! score is '''+str(self.x)+''' press tab to restart'''
            self.won_sound.play()
        
    def _draw(self):
        
        self.screen.blit(self.background, (0, 0))
        
        for game_object in self._get_game_objects():
            game_object.draw(self.screen)
        
        if self.message:
            print_text(self.screen, self.message, self.font)
        
        pygame.display.flip()
        self.clock.tick(60)
        
    def _get_game_objects(self):
        self.n=0
        game_objects = [*self.asteroids, *self.bullets]
        self.n=len(self.asteroids)
        if self.spaceshipx:
            game_objects.append(self.spaceshipx)

        return game_objects