from game import Spacegame
if __name__ == "__main__":
    space_rocks = Spacegame()
    space_rocks.main_loop()
